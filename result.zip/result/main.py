import pygame
import time
import random
pygame.mixer.pre_init(44100, -16, 1, 512)
pygame.init()
COLOR_INACTIVE = pygame.Color('lightskyblue3')
COLOR_ACTIVE = pygame.Color('dodgerblue2')
FONT = pygame.font.Font(None, 32)

#Class

class Button:
    def create_button(self, surface, color, x, y, length, height, width, text, text_color):
        surface = self.draw_button(surface, color, length, height, x, y, width)
        surface = self.write_text(surface, text, text_color, length, height, x, y)
        self.rect = pygame.Rect(x,y, length, height)
        return surface

    def write_text(self, surface, text, text_color, length, height, x, y):
        font_size = int(length//len(text)*2)
        myFont = pygame.font.SysFont("TymesNewRoman", font_size)
        myText = myFont.render(text, 1, text_color)
        surface.blit(myText, ((x+length/2) - myText.get_width()/2, (y+height/2) - myText.get_height()/2))
        return surface

    def draw_button(self, surface, color, length, height, x, y, width):           
        for i in range(1,10):
            s = pygame.Surface((length+(i*2),height+(i*2)))
            s.fill(color)
            alpha = (255/(i+2))
            if alpha <= 0:
                alpha = 1
            s.set_alpha(alpha)
            pygame.draw.rect(s, color, (x-i,y-i,length+i,height+i), width)
            surface.blit(s, (x-i,y-i))
        pygame.draw.rect(surface, color, (x,y,length,height), 0)
        pygame.draw.rect(surface, (190,190,190), (x,y,length,height), 1)  
        return surface

    def pressed(self, mouse):
        if mouse[0] > self.rect.topleft[0]:
            if mouse[1] > self.rect.topleft[1]:
                if mouse[0] < self.rect.bottomright[0]:
                    if mouse[1] < self.rect.bottomright[1]:
                        pass
                        return True
                    else: return False
                else: return False
            else: return False
        else: return False
#def
def sleep_for_seconds():
    begin_time = time.time()
    tim = 0
    while tim < 5:
        end_time = time.time()
        tim = end_time - begin_time
#Nachalo
clock = pygame.time.Clock()
window_size = (1500, 800)
screen = pygame.display.set_mode(window_size)
pygame.display.set_caption("Хороший ли, ты родитель?!")
background_image = pygame.image.load("R.png")
background_image = pygame.transform.scale(background_image, window_size)
screen.blit(background_image, (0, 0))


#create_buttons
But1 = Button()
But2 = Button()
But3 = Button()
But4 = Button()
But5 = Button()
But6 = Button()
But1.create_button(screen, (107,142,35), 50, 700, 150, 70, 70, "Начать новый день", (250, 250, 250))
But2.create_button(screen, (0,0,0), 300, 700, 150, 70, 70, "Сварганить поесть", (255,255,255))
But3.create_button(screen, (0,0,0), 550, 700, 150, 70, 70, "Схрдить на горшок", (255,255,255))
But4.create_button(screen, (0,0,0), 800, 700, 150, 70, 70, "Искупнуться", (255,255,255))
But5.create_button(screen, (0,0,0), 1050, 700, 150, 70, 70, "Сходить в школу", (255,255,255))
But6.create_button(screen, (0,0,0), 1300, 700, 150, 70, 70, "Сходить в парк", (255,255,255))

#kakaya-to hrenb
pygame.display.flip()
running = True

#musical_effects
s = pygame.mixer.Sound("sup-peremeshivayut-v-posude__Pro-Sound.org_.ogg")
sl = pygame.mixer.Sound("0000212--online-audio-convert.com.ogg")
s1 = pygame.mixer.Sound("zvuk-unitaza--online-audio-convert.com.ogg")
s2 = pygame.mixer.Sound("zvuk-dusha--online-audio-convert.com.ogg")
s7 = pygame.mixer.Sound("AmericanRoller.mp3--online-audio-convert.com.ogg")
s8 = pygame.mixer.Sound("Water.mp3--online-audio-convert.com.ogg")
s9 = pygame.mixer.Sound("Karusel.mp3--online-audio-convert.com.ogg")
s6 = pygame.mixer.Sound("Park.mp3--online-audio-convert.com.ogg")
s5 = pygame.mixer.Sound("peremena1.mp3--online-audio-convert.com.ogg")
#status
golod = 2
toulet = 4
gygen = 6
obraz= 1
activity = 5
days = 1
years = 7
Condition = 30

sgol = str(golod)
stou = str(toulet)
sgig = str(gygen)
sobr = str(obraz)
sact = str(activity)
sdays = str(days)
syears = str(years)
if Condition < 25:
    sCon = 'Грустно'
elif Condition < 50:
    sCon = "Нормальное"
elif Condition < 75:
    sCon = "Радостное"
else:
    sCon = "Счастлив"

myFont = pygame.font.SysFont("TymesNewRomans", 30)
mFont = pygame.font.SysFont("TymesNewRomans", 40)
Font = pygame.font.SysFont("TymesNewRomans", 80)
text_surface = mFont.render('День ' + sdays, False, (0, 0, 0))
screen.blit(text_surface, (750,10))
pygame.display.flip()

text_surface = mFont.render('Возраст: ' + syears, False, (0, 0, 0))
screen.blit(text_surface, (1300 ,10))
pygame.display.flip()

text_surface = mFont.render('Состояние: ' + sCon, False, (0, 0, 0))
screen.blit(text_surface, (1150 ,40))
pygame.display.flip()

text_surface = myFont.render('Голод ' + sgol, False, (0, 0, 0))
screen.blit(text_surface, (10,10))
pygame.display.flip()

text_surface = myFont.render('Туалет ' + stou, False, (0, 0, 0))
screen.blit(text_surface, (10,40))
pygame.display.flip()

text_surface = myFont.render('Гигиена ' + sgig, False, (0, 0, 0))
screen.blit(text_surface, (10,70))
pygame.display.flip()

text_surface = myFont.render('Образование ' + sobr, False, (0, 0, 0))
screen.blit(text_surface, (10,100))
pygame.display.flip()

text_surface = myFont.render('Очки Действии ' + sact, False, (0, 0, 0))
screen.blit(text_surface, (10,130))
pygame.display.flip()

#toje hrenb
run = True

while run == True:

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
        if event.type == pygame.MOUSEBUTTONDOWN:
            if But1.pressed(pygame.mouse.get_pos()):
                if golod > 0 and toulet < 10 and gygen > 0 and obraz > 0 and Condition > 0:
                    background_image = pygame.image.load("scale_1200.jpg")
                    sl.play()
                    background_image = pygame.transform.scale(background_image, window_size)
                    screen.blit(background_image, (0, 0))
                    pygame.display.flip()
                    print("Начался новый день")
                    days += 1
                    activity = 5
                    golod -= 1
                    toulet += 1
                    gygen -= 1
                    obraz -= 1
                    Condition -= 1
                    sleep_for_seconds()
                    background_image = pygame.image.load("R.png")
                    background_image = pygame.transform.scale(background_image, window_size)
                    screen.blit(background_image, (0, 0))
                    But1.create_button(screen, (107,142,35), 50, 700, 150, 70, 70, "Начать новый день", (250, 250, 250))
                    But2.create_button(screen, (0,0,0), 300, 700, 150, 70, 70, "Сварганить поесть", (255,255,255))
                    But3.create_button(screen, (0,0,0), 550, 700, 150, 70, 70, "Сходить на горшок", (255,255,255))
                    But4.create_button(screen, (0,0,0), 800, 700, 150, 70, 70, "Искупнуться", (255,255,255))
                    But5.create_button(screen, (0,0,0), 1050, 700, 150, 70, 70, "Сходить в школу", (255,255,255))
                    But6.create_button(screen, (0,0,0), 1300, 700, 150, 70, 70, "Сходить в парк", (255,255,255))
                    sl.stop() 
                    sgol = str(golod)
                    stou = str(toulet)
                    sgig = str(gygen)
                    sobr = str(obraz)
                    sact = str(activity)
                    sdays = str(days)
                    syears = str(years)

                    if Condition < 25:
                        sCon = 'Грустно'
                    elif Condition < 50:
                        sCon = "Нормальное"
                    elif Condition < 75:
                        sCon = "Радостное"
                    else:
                        sCon = "Счастлив"
                    
                    text_surface = mFont.render('Возраст: ' + syears, False, (0, 0, 0))
                    screen.blit(text_surface, (1300 ,10))
                    pygame.display.flip()

                    text_surface = mFont.render('Состояние: ' + sCon, False, (0, 0, 0))
                    screen.blit(text_surface, (1150 ,40))
                    pygame.display.flip()

                    text_surface = mFont.render('День ' + sdays, False, (0, 0, 0))
                    screen.blit(text_surface, (750,10))
                    pygame.display.flip()    

                    text_surface = myFont.render('Голод ' + sgol, False, (0, 0, 0))
                    screen.blit(text_surface, (10,10))
                    pygame.display.flip()

                    text_surface = myFont.render('Туалет ' + stou, False, (0, 0, 0))
                    screen.blit(text_surface, (10,40))
                    pygame.display.flip()

                    text_surface = myFont.render('Гигиена ' + sgig, False, (0, 0, 0))
                    screen.blit(text_surface, (10,70))
                    pygame.display.flip()

                    text_surface = myFont.render('Образование ' + sobr, False, (0, 0, 0))
                    screen.blit(text_surface, (10,100))
                    pygame.display.flip()

                    text_surface = myFont.render('Очки Действии ' + sact, False, (0, 0, 0))
                    screen.blit(text_surface, (10,130))
                    pygame.display.flip()
                else:
                    print('Вашего сына забрала опека, вы плохой родитель!')
                    run = False
            #golod
            elif But2.pressed(pygame.mouse.get_pos()):
                if golod < 10 and activity > 0:
                    background_image = pygame.image.load("0466.jpg")
                    s.play()
                    background_image = pygame.transform.scale(background_image, window_size)
                    screen.blit(background_image, (0, 0))
                    pygame.display.flip()
                    print("Голод пополнен +1")
                    golod += 1
                    print(golod)
                    sleep_for_seconds()                  
                    activity -= 1
                    print("Осталось", activity, "действий(-ия)")
                    background_image = pygame.image.load("R.png")
                    background_image = pygame.transform.scale(background_image, window_size)
                    screen.blit(background_image, (0, 0))
                    But1.create_button(screen, (107,142,35), 50, 700, 150, 70, 70, "Начать новый день", (250, 250, 250))
                    But2.create_button(screen, (0,0,0), 300, 700, 150, 70, 70, "Сварганить поесть", (255,255,255))
                    But3.create_button(screen, (0,0,0), 550, 700, 150, 70, 70, "Сходить на горшок", (255,255,255))
                    But4.create_button(screen, (0,0,0), 800, 700, 150, 70, 70, "Искупнуться", (255,255,255))
                    But5.create_button(screen, (0,0,0), 1050, 700, 150, 70, 70, "Сходить в школу", (255,255,255))
                    But6.create_button(screen, (0,0,0), 1300, 700, 150, 70, 70, "Сходить в парк", (255,255,255))
                    s.stop()
                    if Condition < 25:
                        sCon = 'Грустно'
                    elif Condition < 50:
                        sCon = "Нормальное"
                    elif Condition < 75:
                        sCon = "Радостное"
                    else:
                        sCon = "Счастлив"
                    sgol = str(golod)
                    stou = str(toulet)
                    sgig = str(gygen)
                    sobr = str(obraz)
                    sact = str(activity)
                    sdays = str(days)

                    text_surface = mFont.render('Возраст: ' + syears, False, (0, 0, 0))
                    screen.blit(text_surface, (1300 ,10))
                    pygame.display.flip()

                    text_surface = mFont.render('Состояние: ' + sCon, False, (0, 0, 0))
                    screen.blit(text_surface, (1150 ,40))
                    pygame.display.flip()

                    text_surface = mFont.render('День ' + sdays, False, (0, 0, 0))
                    screen.blit(text_surface, (750,10))
                    pygame.display.flip()    

                    text_surface = myFont.render('Голод ' + sgol, False, (0, 0, 0))
                    screen.blit(text_surface, (10,10))
                    pygame.display.flip()

                    text_surface = myFont.render('Туалет ' + stou, False, (0, 0, 0))
                    screen.blit(text_surface, (10,40))
                    pygame.display.flip()

                    text_surface = myFont.render('Гигиена ' + sgig, False, (0, 0, 0))
                    screen.blit(text_surface, (10,70))
                    pygame.display.flip()

                    text_surface = myFont.render('Образование ' + sobr, False, (0, 0, 0))
                    screen.blit(text_surface, (10,100))
                    pygame.display.flip()

                    text_surface = myFont.render('Очки Действии ' + sact, False, (0, 0, 0))
                    screen.blit(text_surface, (10,130))
                    pygame.display.flip()


                elif activity == 0:
                    print('Действия закончились')
                else:
                    print('Вы не голодны')
            #Toulet
            elif But3.pressed(pygame.mouse.get_pos()):
                if toulet > 0 and activity > 0:
                    background_image = pygame.image.load("62672c99fb37aac4312ed5a85d762d75.jpeg")
                    background_image = pygame.transform.scale(background_image, window_size)
                    screen.blit(background_image, (0, 0))
                    s1.play()
                    pygame.display.flip()
                    print("Потребность в нужде уменьшена на -2")
                    toulet -= 2
                    sleep_for_seconds()
                    s1.stop()
                    print(toulet)
                    background_image = pygame.image.load("R.png")
                    background_image = pygame.transform.scale(background_image, window_size)
                    screen.blit(background_image, (0, 0))
                    But1.create_button(screen, (107,142,35), 50, 700, 150, 70, 70, "Начать новый день", (250, 250, 250))
                    But2.create_button(screen, (0,0,0), 300, 700, 150, 70, 70, "Сварганить поесть", (255,255,255))
                    But3.create_button(screen, (0,0,0), 550, 700, 150, 70, 70, "Сходить на горшок", (255,255,255))
                    But4.create_button(screen, (0,0,0), 800, 700, 150, 70, 70, "Искупнуться", (255,255,255))
                    But5.create_button(screen, (0,0,0), 1050, 700, 150, 70, 70, "Сходить в школу", (255,255,255))
                    But6.create_button(screen, (0,0,0), 1300, 700, 150, 70, 70, "Сходить в парк", (255,255,255))
                    if Condition < 25:
                        sCon = 'Грустно'
                    elif Condition < 50:
                        sCon = "Нормальное"
                    elif Condition < 75:
                        sCon = "Радостное"
                    else:
                        sCon = "Счастлив"
                    sgol = str(golod)
                    stou = str(toulet)
                    sgig = str(gygen)
                    sobr = str(obraz)
                    sact = str(activity)
                    sdays = str(days)

                    text_surface = mFont.render('Возраст: ' + syears, False, (0, 0, 0))
                    screen.blit(text_surface, (1300 ,10))
                    pygame.display.flip()

                    text_surface = mFont.render('Состояние: ' + sCon, False, (0, 0, 0))
                    screen.blit(text_surface, (1150 ,40))
                    pygame.display.flip()

                    text_surface = mFont.render('День ' + sdays, False, (0, 0, 0))
                    screen.blit(text_surface, (750,10))
                    pygame.display.flip()    

                    text_surface = myFont.render('Голод ' + sgol, False, (0, 0, 0))
                    screen.blit(text_surface, (10,10))
                    pygame.display.flip()

                    text_surface = myFont.render('Туалет ' + stou, False, (0, 0, 0))
                    screen.blit(text_surface, (10,40))
                    pygame.display.flip()

                    text_surface = myFont.render('Гигиена ' + sgig, False, (0, 0, 0))
                    screen.blit(text_surface, (10,70))
                    pygame.display.flip()

                    text_surface = myFont.render('Образование ' + sobr, False, (0, 0, 0))
                    screen.blit(text_surface, (10,100))
                    pygame.display.flip()

                    text_surface = myFont.render('Очки Действии ' + sact, False, (0, 0, 0))
                    screen.blit(text_surface, (10,130))
                    pygame.display.flip()
                    activity -= 1
                    print("Осталось", activity, "действий(-ия)")
                elif activity == 0:
                    print('Действия закончились')
                else:
                    print('Вам не нужно в туалет')
            #gygen
            elif But4.pressed(pygame.mouse.get_pos()):
                if gygen < 8 and activity > 0:
                    background_image = pygame.image.load("Bath.jpg")
                    background_image = pygame.transform.scale(background_image, window_size)
                    screen.blit(background_image, (0, 0))
                    pygame.display.flip()
                    s2.play()
                    print("Гигиена пополнена +2")
                    gygen += 2
                    print(gygen)
                    sleep_for_seconds()
                    s2.stop()
                    background_image = pygame.image.load("R.png")
                    background_image = pygame.transform.scale(background_image, window_size)
                    screen.blit(background_image, (0, 0))
                    But1.create_button(screen, (107,142,35), 50, 700, 150, 70, 70, "Начать новый день", (250, 250, 250))
                    But2.create_button(screen, (0,0,0), 300, 700, 150, 70, 70, "Сварганить поесть", (255,255,255))
                    But3.create_button(screen, (0,0,0), 550, 700, 150, 70, 70, "Сходить на горшок", (255,255,255))
                    But4.create_button(screen, (0,0,0), 800, 700, 150, 70, 70, "Искупнуться", (255,255,255))
                    But5.create_button(screen, (0,0,0), 1050, 700, 150, 70, 70, "Сходить в школу", (255,255,255))
                    But6.create_button(screen, (0,0,0), 1300, 700, 150, 70, 70, "Сходить в парк", (255,255,255))
                    
                    activity -= 1
                    print("Осталось", activity, "действий(-ия)")

                    if Condition < 25:
                        sCon = 'Грустно'
                    elif Condition < 50:
                        sCon = "Нормальное"
                    elif Condition < 75:
                        sCon = "Радостное"
                    else:
                        sCon = "Счастлив"
                    sgol = str(golod)
                    stou = str(toulet)
                    sgig = str(gygen)
                    sobr = str(obraz)
                    sact = str(activity)
                    sdays = str(days)

                    text_surface = mFont.render('Возраст: ' + syears, False, (0, 0, 0))
                    screen.blit(text_surface, (1300 ,10))
                    pygame.display.flip()

                    text_surface = mFont.render('Состояние: ' + sCon, False, (0, 0, 0))
                    screen.blit(text_surface, (1150 ,40))
                    pygame.display.flip()

                    text_surface = mFont.render('День ' + sdays, False, (0, 0, 0))
                    screen.blit(text_surface, (750,10))
                    pygame.display.flip()    

                    text_surface = myFont.render('Голод ' + sgol, False, (0, 0, 0))
                    screen.blit(text_surface, (10,10))
                    pygame.display.flip()

                    text_surface = myFont.render('Туалет ' + stou, False, (0, 0, 0))
                    screen.blit(text_surface, (10,40))
                    pygame.display.flip()

                    text_surface = myFont.render('Гигиена ' + sgig, False, (0, 0, 0))
                    screen.blit(text_surface, (10,70))
                    pygame.display.flip()

                    text_surface = myFont.render('Образование ' + sobr, False, (0, 0, 0))
                    screen.blit(text_surface, (10,100))
                    pygame.display.flip()

                    text_surface = myFont.render('Очки Действии ' + sact, False, (0, 0, 0))
                    screen.blit(text_surface, (10,130))
                    pygame.display.flip()
                    
                elif activity == 0:
                    print('Действия закончились')
                else:
                    print('Вы чисты, как граненый алмаз')
            #obraz
            elif But5.pressed(pygame.mouse.get_pos()):
                if activity > 0:
                    s5.play()
                    background_image = pygame.image.load("1669790585_7-4.jpg")
                    background_image = pygame.transform.scale(background_image, window_size)
                    screen.blit(background_image, (0, 0))
                    pygame.display.flip()
                    sleep_for_seconds()
                    s5.stop()
                    print("Образование пополнено +2")
                    obraz += 2
                    print(obraz)
                    activity -= 1
                    print("Осталось", activity, "действий(-ия)")
                    background_image = pygame.image.load("R.png")
                    background_image = pygame.transform.scale(background_image, window_size)
                    screen.blit(background_image, (0, 0))
                    But1.create_button(screen, (107,142,35), 50, 700, 150, 70, 70, "Начать новый день", (250, 250, 250))
                    But2.create_button(screen, (0,0,0), 300, 700, 150, 70, 70, "Сварганить поесть", (255,255,255))
                    But3.create_button(screen, (0,0,0), 550, 700, 150, 70, 70, "Сходить на горшок", (255,255,255))
                    But4.create_button(screen, (0,0,0), 800, 700, 150, 70, 70, "Искупнуться", (255,255,255))
                    But5.create_button(screen, (0,0,0), 1050, 700, 150, 70, 70, "Сходить в школу", (255,255,255))
                    But6.create_button(screen, (0,0,0), 1300, 700, 150, 70, 70, "Сходить в парк", (255,255,255))
                    
                    if Condition < 25:
                        sCon = 'Грустно'
                    elif Condition < 50:
                        sCon = "Нормальное"
                    elif Condition < 75:
                        sCon = "Радостное"
                    else:
                        sCon = "Счастлив"
                    sgol = str(golod)
                    stou = str(toulet)
                    sgig = str(gygen)
                    sobr = str(obraz)
                    sact = str(activity)
                    sdays = str(days)

                    text_surface = mFont.render('Возраст: ' + syears, False, (0, 0, 0))
                    screen.blit(text_surface, (1300 ,10))
                    pygame.display.flip()

                    text_surface = mFont.render('Состояние: ' + sCon, False, (0, 0, 0))
                    screen.blit(text_surface, (1150 ,40))
                    pygame.display.flip()

                    text_surface = mFont.render('День ' + sdays, False, (0, 0, 0))
                    screen.blit(text_surface, (750,10))
                    pygame.display.flip()    

                    text_surface = myFont.render('Голод ' + sgol, False, (0, 0, 0))
                    screen.blit(text_surface, (10,10))
                    pygame.display.flip()

                    text_surface = myFont.render('Туалет ' + stou, False, (0, 0, 0))
                    screen.blit(text_surface, (10,40))
                    pygame.display.flip()

                    text_surface = myFont.render('Гигиена ' + sgig, False, (0, 0, 0))
                    screen.blit(text_surface, (10,70))
                    pygame.display.flip()

                    text_surface = myFont.render('Образование ' + sobr, False, (0, 0, 0))
                    screen.blit(text_surface, (10,100))
                    pygame.display.flip()

                    text_surface = myFont.render('Очки Действии ' + sact, False, (0, 0, 0))
                    screen.blit(text_surface, (10,130))
                    pygame.display.flip()
                elif activity == 0:
                    print('Действия закончились')
            elif But6.pressed(pygame.mouse.get_pos()):
                if activity > 0:
                    s6.play()
                    background_image = pygame.image.load("31826.jpg")
                    background_image = pygame.transform.scale(background_image, window_size)
                    screen.blit(background_image, (0, 0))
                    pygame.display.flip()
                    con = 5
                    sleep_for_seconds()                    
                    s6.stop()
                    print("Радсоть пополнена на +" + str(con))
                    Condition += con
                    print(obraz)
                    activity -= 1
                    print("Осталось", activity, "действий(-ия)")
                    background_image = pygame.image.load("R.png")
                    background_image = pygame.transform.scale(background_image, window_size)
                    screen.blit(background_image, (0, 0))
                    But1.create_button(screen, (107,142,35), 50, 700, 150, 70, 70, "Начать новый день", (250, 250, 250))
                    But2.create_button(screen, (0,0,0), 300, 700, 150, 70, 70, "Сварганить поесть", (255,255,255))
                    But3.create_button(screen, (0,0,0), 550, 700, 150, 70, 70, "Сходить на горшок", (255,255,255))
                    But4.create_button(screen, (0,0,0), 800, 700, 150, 70, 70, "Искупнуться", (255,255,255))
                    But5.create_button(screen, (0,0,0), 1050, 700, 150, 70, 70, "Сходить в школу", (255,255,255))
                    But6.create_button(screen, (0,0,0), 1300, 700, 150, 70, 70, "Сходить в парк", (255,255,255))
                    
                    if Condition < 25:
                        sCon = 'Грустно'
                    elif Condition < 50:
                        sCon = "Нормальное"
                    elif Condition < 75:
                        sCon = "Радостное"
                    else:
                        sCon = "Счастлив"
                    sgol = str(golod)
                    stou = str(toulet)
                    sgig = str(gygen)
                    sobr = str(obraz)
                    sact = str(activity)
                    sdays = str(days)

                    text_surface = mFont.render('Возраст: ' + syears, False, (0, 0, 0))
                    screen.blit(text_surface, (1300 ,10))
                    pygame.display.flip()

                    text_surface = mFont.render('Состояние: ' + sCon, False, (0, 0, 0))
                    screen.blit(text_surface, (1150 ,40))
                    pygame.display.flip()

                    text_surface = mFont.render('День ' + sdays, False, (0, 0, 0))
                    screen.blit(text_surface, (750,10))
                    pygame.display.flip()    

                    text_surface = myFont.render('Голод ' + sgol, False, (0, 0, 0))
                    screen.blit(text_surface, (10,10))
                    pygame.display.flip()

                    text_surface = myFont.render('Туалет ' + stou, False, (0, 0, 0))
                    screen.blit(text_surface, (10,40))
                    pygame.display.flip()

                    text_surface = myFont.render('Гигиена ' + sgig, False, (0, 0, 0))
                    screen.blit(text_surface, (10,70))
                    pygame.display.flip()

                    text_surface = myFont.render('Образование ' + sobr, False, (0, 0, 0))
                    screen.blit(text_surface, (10,100))
                    pygame.display.flip()

                    text_surface = myFont.render('Очки Действии ' + sact, False, (0, 0, 0))
                    screen.blit(text_surface, (10,130))
                    pygame.display.flip()
                elif activity == 0:
                    print('Действия закончились')

            if days == 5:
                years += 1
            elif days == 10:
                years += 1
            elif days == 15:
                years += 1
            elif days == 20:
                years += 1
            elif days == 25:
                years += 1
            elif days == 30:
                years += 1
            elif days == 35:
                years += 1
            elif days == 40:
                years += 1
            elif days == 45:
                years += 1
            elif days == 50:
                years += 1
            elif days == 55:
                years += 1
            elif years == 18:
                if obraz < 10:
                    print('Ваш сын стал бомжом, вы плохой родитель!')
                    run = False
                else:
                    print('Ваш сын выросл здоровым!')
                    if obraz > 20 and obraz < 30:
                        print('Он стал доктором')
                        run = False
                    elif obraz > 30 and obraz < 40:
                        print('Он стал Глав. Врачом')
                        run = False
                    elif obraz > 40 and obraz < 50:
                        print('Он стал мэром Москвы')
                        run = False
                    elif obraz > 50:
                        print('Он стал президентом Россий')
                        run = False
                    else:
                        print('Bomj')
                        run = False

    pygame.display.update()
clock.tick(120)
pygame.quit()
